import  testando  from './js.js';

testando()